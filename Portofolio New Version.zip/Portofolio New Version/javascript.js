document.addEventListener('DOMContentLoaded', function() {

    const IS_REDUCED_MOTION = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const MOBILE_BREAKPOINT = 480; // Lebar maksimal untuk tampilan mobile (hamburger)

    // --- Cache Frequently Used Elements ---
    const navigation = document.getElementById('navigation');
    const navContainer = navigation ? navigation.querySelector('.nav-container') : null;
    const navUl = navContainer ? navContainer.querySelector('ul') : null;
    const heroSection = document.getElementById('hero'); // Pastikan heroSection diambil di sini
    const starsContainer = document.querySelector('.stars'); // Untuk efek bintang jika ada
    const body = document.body;

    // --- Fungsi Baru: Menyesuaikan Padding Hero untuk Navbar ---
    function adjustHeroPaddingForNav() {
        if (navigation && heroSection) {
            const navHeight = navigation.offsetHeight; // Dapatkan tinggi aktual navbar
            const buffer = 80; // Tambahkan sedikit ruang ekstra (sesuaikan jika perlu)
            heroSection.style.paddingTop = `${navHeight + buffer}px`;
            // console.log(`Navbar height: ${navHeight}px, Hero padding-top set to: ${navHeight + buffer}px`); // Uncomment for debugging
        }
    }

    // --- 1. Smooth Scroll Internal Links ---
    function setupSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                if (href && href.length > 1 && href.startsWith('#')) {
                    e.preventDefault();
                    const targetId = href.substring(1);
                    const targetElement = document.getElementById(targetId);
                    if (targetElement) {
                        // Close mobile menu before scrolling
                        if (body.classList.contains('mobile-menu-active')) {
                            toggleMobileMenu(false); // Pastikan menu tertutup
                            if (updateHamburgerStyles) updateHamburgerStyles(false); // Reset button state
                        }

                        // Menggunakan tinggi nav yang dinamis untuk offset scroll
                        const navHeight = navigation ? navigation.offsetHeight : 0;
                        const buffer = 20; // Buffer yang sama seperti di adjustHeroPaddingForNav
                        const elementPosition = targetElement.getBoundingClientRect().top;
                        // Offset dikurangi tinggi nav DAN buffer agar berhenti sedikit di bawah nav
                        const offsetPosition = elementPosition + window.pageYOffset - navHeight - buffer;

                        window.scrollTo({
                            top: offsetPosition < 0 ? 0 : offsetPosition, // Hindari scroll ke nilai negatif
                            behavior: IS_REDUCED_MOTION ? 'auto' : 'smooth'
                        });

                        // Highlight active link (basic)
                        setActiveNavLink(href);
                    }
                }
            });
        });
    }

    // --- 2. Navbar Scroll Effect ---
    function setupNavbarScrollEffect() {
        if (!navigation) return;
        let lastScrollY = window.scrollY;
        let ticking = false;

        window.addEventListener('scroll', function() {
            lastScrollY = window.scrollY;
            if (!ticking) {
                window.requestAnimationFrame(function() {
                    const scrolled = lastScrollY > 50;
                    // Terapkan class scrolled
                    if (scrolled) {
                        navigation.classList.add('scrolled');
                    } else {
                        navigation.classList.remove('scrolled');
                    }
                    // Panggil adjustHeroPaddingForNav setelah class 'scrolled' diubah,
                    // karena tinggi nav mungkin berubah (meskipun ResizeObserver lebih baik)
                    // adjustHeroPaddingForNav(); // Dihandle oleh ResizeObserver

                    // Update active nav link on scroll
                    updateActiveNavLinkOnScroll();
                    ticking = false;
                });
                ticking = true;
            }
        });
    }

    // --- 3. Active Navigation Link Highlighting ---
    const navLinks = navUl ? Array.from(navUl.querySelectorAll('a[href^="#"]')) : [];
    // Pastikan section diambil dengan benar
    const sections = navLinks.map(link => {
        const targetId = link.getAttribute('href').substring(1);
        return document.getElementById(targetId);
    }).filter(Boolean); // Filter null/undefined jika elemen tidak ditemukan

    function setActiveNavLink(targetHref) {
        navLinks.forEach(link => {
            link.classList.remove('active'); // 'active' class style defined in CSS
            if (link.getAttribute('href') === targetHref) {
                link.classList.add('active');
            }
        });
    }

    function updateActiveNavLinkOnScroll() {
        if (IS_REDUCED_MOTION || !sections.length) return; // Jangan jalankan jika tidak ada section

        const navHeight = navigation ? navigation.offsetHeight : 60;
        const buffer = 20; // Buffer yang sama
        // Threshold sedikit di bawah navbar + buffer + tambahan offset agar lebih akurat
        const scrollThreshold = window.scrollY + navHeight + buffer + 50; // Tambah 50px lagi

        let currentSectionId = '';

        // Iterasi dari bawah ke atas untuk menemukan section aktif terakhir
        for (let i = sections.length - 1; i >= 0; i--) {
           const section = sections[i];
           // Periksa apakah bagian atas section berada di atas threshold
           if (section.offsetTop <= scrollThreshold) {
                currentSectionId = '#' + section.id;
                break; // Ambil yang pertama kali memenuhi syarat dari bawah
            }
        }


        // Jika masih kosong (misal di paling atas sebelum hero), coba aktifkan yang pertama
         if (!currentSectionId && navLinks.length > 0 && window.scrollY < sections[0].offsetTop / 2) {
            currentSectionId = navLinks[0].getAttribute('href');
         }

        if (currentSectionId) {
            setActiveNavLink(currentSectionId);
        } else {
             // Deactivate all if no section matches (optional)
             navLinks.forEach(link => link.classList.remove('active'));
        }
    }


    // --- 4. Hamburger Menu for Mobile ---
    let hamburgerButton = null;
    let mobileMediaQuery = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT}px)`);
    let updateHamburgerStyles = null;

    function createHamburgerButton() {
        if (!navContainer || hamburgerButton) return; hamburgerButton = document.createElement('button'); hamburgerButton.setAttribute('id', 'hamburger-button'); hamburgerButton.setAttribute('aria-label', 'Toggle Navigation Menu'); hamburgerButton.setAttribute('aria-expanded', 'false'); hamburgerButton.innerHTML = `<span class="hamburger-box"><span class="hamburger-inner"></span></span>`; Object.assign(hamburgerButton.style, { position: 'absolute', top: '50%', right: '15px', transform: 'translateY(-50%)', zIndex: '1100', padding: '10px', display: 'none', /* Display none awal dihapus, dihandle CSS */ cursor: 'pointer', background: 'transparent', border: 'none', width: '40px', height: '40px', transition: 'opacity 0.3s ease', }); const spanBoxStyle = { display: 'inline-block', position: 'relative', width: '24px', height: '20px' }; const spanInnerStyle = { display: 'block', position: 'absolute', width: '100%', height: '2px', backgroundColor: 'var(--color-primary-glow)', borderRadius: '2px', transition: 'transform 0.3s ease, background-color 0.3s ease' }; const hamburgerBox = hamburgerButton.querySelector('.hamburger-box'); const hamburgerInner = hamburgerButton.querySelector('.hamburger-inner'); Object.assign(hamburgerBox.style, spanBoxStyle); Object.assign(hamburgerInner.style, spanInnerStyle); hamburgerInner.style.top = '50%'; hamburgerInner.style.transform = 'translateY(-50%)'; const innerBefore = document.createElement('span'); const innerAfter = document.createElement('span'); Object.assign(innerBefore.style, spanInnerStyle); Object.assign(innerAfter.style, spanInnerStyle); innerBefore.style.top = '0'; innerAfter.style.bottom = '0'; hamburgerBox.insertBefore(innerBefore, hamburgerInner); hamburgerBox.appendChild(innerAfter); function setActiveStyles(isActive) { hamburgerButton.setAttribute('aria-expanded', isActive); hamburgerInner.style.backgroundColor = isActive ? 'transparent' : 'var(--color-primary-glow)'; innerBefore.style.backgroundColor = 'var(--color-primary-glow)'; innerAfter.style.backgroundColor = 'var(--color-primary-glow)'; innerBefore.style.transform = isActive ? 'translateY(9px) rotate(45deg)' : 'none'; innerAfter.style.transform = isActive ? 'translateY(-9px) rotate(-45deg)' : 'none'; } hamburgerButton.addEventListener('click', () => { const isActive = !body.classList.contains('mobile-menu-active'); toggleMobileMenu(isActive); setActiveStyles(isActive); }); navContainer.appendChild(hamburgerButton);
        // Tampilkan tombol hamburger via JS karena awalnya disembunyikan oleh CSS parent (.navigation ul)
        if (mobileMediaQuery.matches) {
             hamburgerButton.style.display = 'block';
        }
        return setActiveStyles;
    }

    function toggleMobileMenu(show) {
         if (!navUl) return; body.classList.toggle('mobile-menu-active', show);
         const basePaddingTop = navigation ? navigation.offsetHeight : 60;
         const extraPaddingTop = 60;
         const navTopStyle = navigation ? window.getComputedStyle(navigation).top : '0px';
         const navTop = parseFloat(navTopStyle) || 0;

         Object.assign(navUl.style, {
            // display: flex HARUS di set di sini agar menu muncul
            display: 'flex',
            position: 'fixed', top: `${navTop}px`, left: '0', width: '100%', height: `calc(100vh - ${navTop}px)`,
            background: 'rgba(5, 5, 16, 0.95)', backdropFilter: 'blur(10px)', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', paddingTop: `${extraPaddingTop}px`,
            transform: show ? 'translateX(0%)' : 'translateX(100%)',
            transition: IS_REDUCED_MOTION ? 'none' : 'transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), opacity 0.4s ease', // Tambahkan opacity transition
            opacity: show ? '1' : '0', pointerEvents: show ? 'auto' : 'none', zIndex: '1050'
        });
        // Hapus style display saat menu ditutup agar kembali ke display:none dari CSS
         if (!show) {
             // Beri sedikit delay agar transisi selesai sebelum display none
             setTimeout(() => {
                 // Pastikan menu masih harus disembunyikan (jika user tidak klik lagi)
                 if (!body.classList.contains('mobile-menu-active')) {
                      navUl.style.display = 'none';
                 }
             }, 400); // Sesuaikan delay dengan durasi transisi transform
         }

        navLinks.forEach(link => { Object.assign(link.style, { fontSize: '1.5rem', padding: '15px 0', color: 'var(--color-text-primary)', opacity: show ? '1' : '0', transform: show ? 'translateY(0)' : 'translateY(10px)', transition: IS_REDUCED_MOTION ? 'none' : `opacity 0.3s ease ${show ? '0.3s' : '0s'}, transform 0.3s ease ${show ? '0.3s' : '0s'}`, }); link.removeEventListener('click', closeMenuOnClick); link.addEventListener('click', closeMenuOnClick); });
    }

    function closeMenuOnClick() { if (body.classList.contains('mobile-menu-active')) { toggleMobileMenu(false); if (updateHamburgerStyles) updateHamburgerStyles(false); } }

    function handleMobileNav(event) {
        if (event.matches) { // Layar kecil (< 480px)
            if (!hamburgerButton) {
                updateHamburgerStyles = createHamburgerButton();
            }
             // Pastikan hamburger muncul (CSS mungkin menyembunyikannya jika di dalam .navigation ul)
             if (hamburgerButton) hamburgerButton.style.display = 'block';
             // CSS sudah handle display:none untuk navUl, jadi tidak perlu JS set display:none di sini
             // if (navUl) navUl.style.display = 'none';
             if (!body.classList.contains('mobile-menu-active')) {
                 // Pastikan menu tertutup & display:none saat load / resize ke mobile
                 toggleMobileMenu(false);
             }
             // Pastikan style top dari CSS media query terbaca
             adjustHeroPaddingForNav();

        } else { // Layar besar (>= 480px)
            if (hamburgerButton) hamburgerButton.style.display = 'none';
             if (body.classList.contains('mobile-menu-active')) {
                 toggleMobileMenu(false);
                 if (updateHamburgerStyles) updateHamburgerStyles(false);
             }
            // Restore default display UL (flex) dan hapus style inline menu mobile
            if (navUl) {
                 navUl.style.display = ''; // Kembali ke display flex dari CSS dasar
                 navUl.style.position = ''; navUl.style.top = ''; navUl.style.left = ''; navUl.style.width = '';
                 navUl.style.height = ''; navUl.style.background = ''; navUl.style.backdropFilter = '';
                 navUl.style.flexDirection = ''; navUl.style.alignItems = ''; navUl.style.justifyContent = '';
                 navUl.style.paddingTop = ''; navUl.style.transform = ''; navUl.style.transition = '';
                 navUl.style.opacity = ''; navUl.style.pointerEvents = ''; navUl.style.zIndex = '';
                 navLinks.forEach(link => { link.style.fontSize = ''; link.style.padding = ''; link.style.color = ''; link.style.opacity = ''; link.style.transform = ''; link.style.transition = ''; link.removeEventListener('click', closeMenuOnClick); });
            }
            // Hapus style inline 'top' dari navigation agar kembali ke top:0 default
            if (navigation) {
                navigation.style.top = '';
            }
            // Recalculate hero padding for desktop view
            adjustHeroPaddingForNav();
        }
    }

    // --- 5. Animation on Scroll (Enhanced Intersection Observer) ---
    function setupScrollAnimations() {
        const elementsToAnimate = document.querySelectorAll('.animate-on-scroll, .animate-fade-in-up'); // Include existing classes

        if ("IntersectionObserver" in window && !IS_REDUCED_MOTION) {
            const observerOptions = {
                threshold: 0.15, // Trigger slightly later
                rootMargin: '0px 0px -60px 0px' // Start animation slightly before fully in view
            };

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach((entry, index) => {
                    if (entry.isIntersecting) {
                        // Add staggered delay based on element index or custom data attribute
                        const delay = entry.target.dataset.animationDelay || (index * 100); // ms
                        entry.target.style.transitionDelay = `${delay}ms`;
                        entry.target.classList.add('is-visible'); // Add class to trigger CSS animation
                        observer.unobserve(entry.target); // Stop observing once animated
                    }
                });
            }, observerOptions);

            elementsToAnimate.forEach(element => {
                // Initial hidden state
                element.style.opacity = '0';
                if (element.classList.contains('animate-fade-in-up')) {
                     element.style.transform = 'translateY(30px)';
                } else if (element.classList.contains('animate-scale-in')) {
                    element.style.transform = 'scale(0.8)';
                }
                element.style.transition = 'opacity 0.6s ease, transform 0.6s cubic-bezier(0.25, 0.8, 0.25, 1)'; // Base transition
                observer.observe(element);
            });

             // Add .is-visible styles dynamically via JS
             const styleSheet = document.createElement("style");
             styleSheet.innerText = `.is-visible { opacity: 1 !important; transform: none !important; }`;
             document.head.appendChild(styleSheet);

        } else {
            // Fallback
            elementsToAnimate.forEach(element => {
                element.classList.add('is-visible'); element.style.opacity = '1';
                element.style.transform = 'none'; element.style.transition = 'none';
            });
        }
    }

    // --- 6. Initialize Swiper for Portfolio ---
    function setupSwiper() {
        if (typeof Swiper !== 'undefined') {
            const portfolioSwiper = new Swiper('.portfolio-swiper', {
                // Optional parameters
                slidesPerView: 1, // Default untuk mobile
                spaceBetween: 25, // Jarak antar slide sedikit ditambah
                grabCursor: true, // Aktifkan kursor grab
                centeredSlides: true, // <<-- BUAT SLIDE AKTIF DI TENGAH
                loop: true,          // <<-- AKTIFKAN LOOP TAK TERBATAS

                // Responsive breakpoints
                breakpoints: {
                    // Sesuaikan slidesPerView jika perlu agar efek center terlihat bagus
                    640: {
                        slidesPerView: 2, // Mungkin 2 atau 'auto' lebih baik dengan centeredSlides
                        spaceBetween: 30
                    },
                    992: {
                        slidesPerView: 3, // Mungkin 3 atau 'auto' lebih baik dengan centeredSlides
                        spaceBetween: 40 // Tambah space sedikit di layar besar
                    }
                },

                // Pagination
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },

                // Navigation arrows
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },

                // Keyboard navigation
                keyboard: {
                    enabled: true,
                    onlyInViewport: false, // Biarkan keyboard berfungsi meski Swiper tidak fokus
                },

                // Efek Scaling untuk Slide Tengah
                watchSlidesProgress: true,
                on: {
                    progress: function() {
                         if (IS_REDUCED_MOTION) { // Jika reduced motion, jangan pakai efek scale
                             const swiper = this;
                             for (let i = 0; i < swiper.slides.length; i++) {
                                 const slide = swiper.slides[i];
                                 slide.style.transform = 'scale(1)';
                                 slide.style.opacity = '1';
                             }
                             return;
                         };

                         const swiper = this;
                         const centerScale = 1.05; // <<-- Skala untuk slide tengah (sedikit lebih besar)
                         const otherScale = 0.85; // <<-- Skala untuk slide lain (lebih kecil)
                         const centerOpacity = 1;   // <<-- Opacity slide tengah
                         const otherOpacity = 0.7; // <<-- Opacity slide lain

                         for (let i = 0; i < swiper.slides.length; i++) {
                             const slide = swiper.slides[i];
                             // Gunakan slide.isActive yang disediakan Swiper saat centeredSlides=true
                             const scale = slide.isActive ? centerScale : otherScale;
                             const opacity = slide.isActive ? centerOpacity : otherOpacity;

                             slide.style.transform = `scale(${scale})`;
                             slide.style.opacity = opacity;
                             // Pastikan ada transisi agar smooth
                             slide.style.transitionProperty = 'transform, opacity';
                             // Durasi transisi bisa diambil dari swiper.params.speed atau set manual
                             // slide.style.transitionDuration = `${swiper.params.speed}ms`; // Gunakan speed swiper
                             slide.style.transitionDuration = '400ms'; // Atau set manual (e.g., 400ms)
                             slide.style.transitionTimingFunction = 'ease'; // Timing function
                         }
                     },
                    setTransition: function(transition) {
                         // Fungsi ini dipanggil saat transisi antar slide dimulai
                         // Kita set transisi di 'progress' agar lebih konsisten saat user drag
                         // Jadi, fungsi ini bisa dikosongkan atau digunakan untuk hal lain jika perlu
                         // const swiper = this;
                         // for (let i = 0; i < swiper.slides.length; i++) {
                         //     swiper.slides[i].style.transitionDuration = `${transition}ms`;
                         // }
                     }
                }
            });
        } else {
            console.warn('Swiper library not found.');
        }
    }

    // --- 7. Enhanced Star Background Effect ---
    function setupStarEffect() {
        if (!starsContainer || IS_REDUCED_MOTION) return;
        const starCount = 180; const fragment = document.createDocumentFragment();
        for (let i = 0; i < starCount; i++) {
            const star = document.createElement('div'); star.classList.add('star-particle');
            const size = Math.random() * 2.2 + 0.4; const duration = Math.random() * 4 + 3; const delay = Math.random() * 5;
            Object.assign(star.style, {
                 position: 'absolute', width: `${size}px`, height: `${size}px`, top: `${Math.random() * 100}%`, left: `${Math.random() * 100}%`,
                 background: `rgba(255, 255, 255, ${Math.random() * 0.5 + 0.3})`, borderRadius: '50%',
                 boxShadow: `0 0 ${size * 2}px rgba(0, 240, 255, 0.5)`, animation: `twinkle ${duration}s linear ${delay}s infinite alternate`,
                 pointerEvents: 'none', opacity: '0'
            });
            fragment.appendChild(star);
        }
        starsContainer.appendChild(fragment);
         const styleSheet = document.createElement("style");
         styleSheet.innerText = `@keyframes twinkle { 0% { opacity: 0; transform: scale(0.8); } 50% { opacity: 1; } 100% { opacity: 0; transform: scale(1.1); } }`;
         document.head.appendChild(styleSheet);
    }

    // --- 8. Interactive Effects (Example: Mouse Parallax on Hero) ---
    function setupHeroParallax() {
        if (!heroSection || IS_REDUCED_MOTION) return;
        const profileElement = heroSection.querySelector('#profile'); const heroTitle = heroSection.querySelector('h1');
        const intensity = 15;
        heroSection.addEventListener('mousemove', (e) => {
            const rect = heroSection.getBoundingClientRect(); const mouseX = e.clientX - rect.left - rect.width / 2; const mouseY = e.clientY - rect.top - rect.height / 2;
            const moveX = (mouseX / rect.width) * intensity; const moveY = (mouseY / rect.height) * intensity;
            window.requestAnimationFrame(() => {
                if (profileElement) { profileElement.style.transform = `translate(${moveX * 0.5}px, ${moveY * 0.5}px) rotateY(${moveX * 0.1}deg) rotateX(${-moveY * 0.1}deg)`; profileElement.style.transition = 'transform 0.1s linear'; }
                if (heroTitle) { heroTitle.style.transform = `translate(${moveX * 0.2}px, ${moveY * 0.2}px)`; heroTitle.style.transition = 'transform 0.1s linear'; }
            });
        });
        heroSection.addEventListener('mouseleave', () => {
             window.requestAnimationFrame(() => {
                if (profileElement) { profileElement.style.transform = 'translate(0, 0) rotateY(0) rotateX(0)'; profileElement.style.transition = 'transform 0.5s cubic-bezier(0.25, 0.8, 0.25, 1)'; }
                if (heroTitle) { heroTitle.style.transform = 'translate(0, 0)'; heroTitle.style.transition = 'transform 0.5s cubic-bezier(0.25, 0.8, 0.25, 1)'; }
             });
        });
    }

    // --- 9. Skill Item Interaction Enhancement (Example) ---
    function setupSkillInteraction() {
        const skillItems = document.querySelectorAll('.skill-item');
        if (!skillItems.length || IS_REDUCED_MOTION) return;
        skillItems.forEach(item => {
            item.addEventListener('mousemove', (e) => {
                const rect = item.getBoundingClientRect(); const x = e.clientX - rect.left; const y = e.clientY - rect.top;
                const centerX = rect.width / 2; const centerY = rect.height / 2; const deltaX = x - centerX; const deltaY = y - centerY;
                const rotateX = (deltaY / centerY) * -6; const rotateY = (deltaX / centerX) * 6;
                 window.requestAnimationFrame(() => {
                     item.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.05) translateY(-5px)`;
                     item.style.transition = 'transform 0.1s linear';
                 });
            });
            item.addEventListener('mouseleave', () => {
                 window.requestAnimationFrame(() => {
                     item.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1) translateY(0)';
                     item.style.transition = 'transform 0.5s cubic-bezier(0.25, 0.8, 0.25, 1)';
                 });
            });
        });
    }

    // --- Initialization ---
    setupSmoothScroll();
    setupNavbarScrollEffect();
    // Panggil adjustHeroPaddingForNav di awal setelah DOM siap
    setTimeout(adjustHeroPaddingForNav, 50); // Sedikit delay
    updateActiveNavLinkOnScroll();
    handleMobileNav(mobileMediaQuery); // Initial check for hamburger menu state
    mobileMediaQuery.addEventListener('change', handleMobileNav); // Listen for viewport changes
    setupScrollAnimations();
    setupSwiper();
    setupStarEffect();
    setupHeroParallax();
    setupSkillInteraction();

    // Gunakan ResizeObserver untuk memanggil adjustHeroPaddingForNav
    // saat ukuran navbar berubah (lebih efisien daripada window.resize)
    if ('ResizeObserver' in window && navigation) {
        const resizeObserver = new ResizeObserver(adjustHeroPaddingForNav);
        resizeObserver.observe(navigation);
    } else {
        // Fallback untuk browser lama jika ResizeObserver tidak didukung
        window.addEventListener('resize', adjustHeroPaddingForNav);
    }

    // --- Add more initialization functions here as needed ---
    console.log("Futuristic Portfolio JS Initialized - v2.6 (Navbar Offset Added)");

}); // Akhir dari DOMContentLoaded